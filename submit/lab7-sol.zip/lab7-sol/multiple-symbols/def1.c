extern int sym;
