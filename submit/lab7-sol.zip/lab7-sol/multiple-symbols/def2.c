int sym = 42;
